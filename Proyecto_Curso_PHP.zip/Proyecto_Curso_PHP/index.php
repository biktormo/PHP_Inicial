<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Don Victor &mdash; prueba curso de PHP</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="prueba curso de PHP" />
	<meta name="keywords" content="prueba curso de PHP" />
	<meta name="author" content="victor" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Bootstrap DateTimePicker -->
	<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.html">DON VICTOR <em>.</em></a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li><a href="#">Menú</a></li>
						<li class="has-dropdown">
							<a href="#">Servicios</a>
							<ul class="dropdown">
								<li><a href="#">Catering</a></li>
								<li><a href="#">Bodas</a></li>
								<li><a href="#">Cumpleaños</a></li>
							</ul>
						</li>
						<li><a href="#">Contacto</a></li>
						<li class="btn-cta"><a href="#"><span>Reservaciones</span></a></li>
					</ul>	
				</div>
			</div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url(images/img_bg_1.jpg)" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
							<span class="intro-text-small">Hecho para el curso :) <a href="https://sceu.frba.utn.edu.ar/e-learning/detalle/curso/2121/php-y-my-sql-inicial" target="_blank">Curso PHP Inicial</a></span>
							<h1 class="cursive-font">¡¡Probando PHP!!</h1>	
						</div>
						<div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight">
				</div>
			</div>
		</div>
	</header>

	
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2 class="cursive-font primary-color">Platos Más Populares</h2>
					<p>Te presentamos algunos de los platos más clásicos de nuestro país</p>
				</div>
			</div>
		
			<!---Variables PHP--->
			<?php
                        $comida1= "Asado Argentino";
						$comida2= "Locro criollo";
						$comida3= "Choripán";
						$comida4= "Empanadas de carne";
						$comida5= "Pizza";
						$comida6= "Milanesa a la napolitana";
                        $descripcion1= "El plato argentino por excelencia. El asado incluye diferentes tipos de cortes de carne que se asan en una parrilla a fuego lento. Incluye 
						chorizos, morcillas, chinchulines, matambre de vaca o de cerdo, costillas, etc."; 
						$descripcion2= "El locro es otro de los platos nacionales por excelencia. Se trata de una especie de sopa espesa y abundante hecha de maíz, 
						frijoles, papas, calabaza y algún tipo de carne, condimentados con comino, laurel, ajo, perejil y otras hierbas.";
						$descripcion3= "El choripán, como su nombre indica, está compuesto por chorizo y pan, formando una especie de sándwich. El chorizo se prepara en 
						diferentes partes del mundo y es más conocido como salchicha de cerdo. En Argentina también se hace con carne de vaca y normalmente se lo cocina en una parrilla.";
						$descripcion4= "Son trozos de masa rellenos con carne picada o cortada a mano, sazonada con comino y cebolla. Estos son los ingredientes más tradicionales, 
						pero también pueden hacerse con jamón y queso, verduras, pollo, maíz dulce, etc.";
						$descripcion5= "Claramente influenciada por la cocina italiana, pero con muchísimas variantes locales, la pizza argentina tiene una corteza gruesa, salsa de tomate, mucho
						 queso y los más variados ingredientes encima. Puede pedir pizzas de cebolla, de jamón, huevo y aceitunas, de pollo, palmitos, choclo, etc.";
						$descripcion6= "La milanesa a la napolitana es un trozo de carne vacuno empanado, frito o al horno, con queso y rodajas o salsa de tomate encima; 
						 se la acompaña normalmente con una ensalada de lechugas, papas fritas o puré de papas.";
                        $precioar1= "1200";
						$precioar2= "700";
						$precioar3= "300";
						$precioar4= "150";
						$precioar5= "900";
						$precioar6= "1000";
                        $dolar= "110";
                    
        	 ?>

			<!---OPERACIONES PHP--->
			<?php 
			$preciousd1 = $precioar1 / $dolar;
			$preciousd2 = $precioar2 / $dolar;
			$preciousd3 = $precioar3 / $dolar;
			$preciousd4 = $precioar4 / $dolar;
			$preciousd5 = $precioar5 / $dolar;
			$preciousd6 = $precioar6 / $dolar;
			?>

			<div class="row">

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/img_01.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/img_01.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">

						<!---Practica de variables PHP--->
						<?php echo "<h2>$comida1</h2>"; ?>
						<?PHP echo "<p>$descripcion1<p>"; ?>

						<!---Practica de Operaciones PHP--->
						<p><span class="price cursive-font">AR$ <?php echo $precioar1; ?> </span></p>
						<p><span class="price cursive-font">USD <?php echo round ($preciousd1); ?> </span></p>

						</div>
					</a>
				</div>


				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/img_02.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/img_02.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">

						<!---Practica de variables PHP--->
						<?php echo "<h2>$comida2</h2>"; ?>
						<?PHP echo "<p>$descripcion2<p>"; ?>

						<!---Practica de Operaciones PHP--->
						<p><span class="price cursive-font">AR$ <?php echo $precioar2; ?> </span></p>
						<p><span class="price cursive-font">USD <?php echo round ($preciousd2); ?> </span></p>

						</div>
					</a>
				</div>



				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/img_03.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/img_03.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
						
						<!---Practica de variables PHP--->
						<?php echo "<h2>$comida3</h2>"; ?>
						<?PHP echo "<p>$descripcion3<p>"; ?>

						<!---Practica de Operaciones PHP--->
						<p><span class="price cursive-font">AR$ <?php echo $precioar3; ?> </span></p>
						<p><span class="price cursive-font">USD <?php echo round ($preciousd3); ?> </span></p>

						</div>
					</a>
				</div>


				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/img_04.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/img_04.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
						
						<!---Practica de variables PHP--->
						<?php echo "<h2>$comida4</h2>"; ?>
						<?PHP echo "<p>$descripcion4<p>"; ?>

						<!---Practica de Operaciones PHP--->
						<p><span class="price cursive-font">AR$ <?php echo $precioar4; ?> </span></p>
						<p><span class="price cursive-font">USD <?php echo round ($preciousd4); ?> </span></p>
						</div>
					</a>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/img_05.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/img_05.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							
						<!---Practica de variables PHP--->
						<?php echo "<h2>$comida5</h2>"; ?>
						<?PHP echo "<p>$descripcion5<p>"; ?>

						<!---Practica de Operaciones PHP--->
						<p><span class="price cursive-font">AR$ <?php echo $precioar5; ?> </span></p>
						<p><span class="price cursive-font">USD <?php echo round ($preciousd5); ?> </span></p>
						</div>
					</a>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/img_06.jpg" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/img_06.jpg" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							
						<!---Practica de variables PHP--->
						<?php echo "<h2>$comida6</h2>"; ?>
						<?PHP echo "<p>$descripcion6<p>"; ?>

						<!---Practica de Operaciones PHP--->
						<p><span class="price cursive-font">AR$ <?php echo $precioar6; ?> </span></p>
						<p><span class="price cursive-font">USD <?php echo round ($preciousd6); ?> </span></p>
						</div>
					</a>
				</div>

			</div>
		</div>
	</div>
	
	<div id="gtco-features">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">

				<!---Practica de Constantes PHP--->
					<?php const CONSTANTE = "Nuestros Servicios";?>
					<h2 class="cursive-font"><?php echo CONSTANTE;?></h2>

					<p>Porque no solamente te brindamos el mejor servicio de restaurant...</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="ti-face-smile"></i>
						</span>

						<!---Practica de Constantes/array PHP--->
						<?php const SERVICIOS = array ("Eventos Felices","Comida a domicilio","Cursos de Cocina Gourmet" );?>

						<h3><?php echo SERVICIOS[0];?></h3>
						<p>Preparamos los mejores platos pensando en lo mejor para tu evento, ya sea cumpleaños, bodas, aniversarios, etc.</p>
					</div>
				</div>

				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="ti-truck"></i>
						</span>
						<h3><?php echo SERVICIOS[1];?></h3>
						<p>Te damos la posibilidad de disfrutar de los mejores sabores en la comodidad de tu hogar</p>
					</div>
				</div>

				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="ti-thought"></i>
						</span>
						<h3><?php echo SERVICIOS[2];?></h3>
						<p>Capacitate y mejorá tus técnicas culinarias con los mejores chefs del mercado</p>
					</div>
				</div>	

			</div>
		</div>
	</div>


	<footer id="gtco-footer" role="contentinfo" style="background-image: url(images/img_bg_1.jpg)" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row row-pb-md">

				

				
				<div class="col-md-12 text-center">
					<div class="gtco-widget">
						<h3>Contacto</h3>
						<ul class="gtco-quick-contact">
							<li><a href="#"><i class="icon-phone"></i> +54 3731 540 501</a></li>
							<li><a href="#"><i class="icon-mail2"></i> biktormo@hotmail.com</a></li>
							<li><a href="#"><i class="icon-chat"></i> Chat Online</a></li>
						</ul>
					</div>
					<div class="gtco-widget">
						<h3>Nuestras Redes</h3>
						<ul class="gtco-social-icons">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
						</ul>
					</div>
				</div>

				<div class="col-md-12 text-center copyright">
					<p><small class="block">&copy; 2021 Curso PHP </small> 
						<small class="block">En proceso de diseño por <a href="https://centerweb.com.ar/" target="_blank">centerweb.com.ar</a></small></p>
				</div>

			</div>

			

		</div>
	</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	
	<script src="js/moment.min.js"></script>
	<script src="js/bootstrap-datetimepicker.min.js"></script>


	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

